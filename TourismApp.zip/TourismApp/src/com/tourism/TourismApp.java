package com.tourism;

import java.util.*;

public class TourismApp {
    public static void main(String[] args) {
        Authentication auth = new Authentication();
        Transport transport = new Transport();
        Region region = new Region();

        Scanner scanner = new Scanner(System.in);
        User currentUser = null;
        List<Booking> bookings = new ArrayList<>();

        while (true) {
            System.out.println("1. Sign Up");
            System.out.println("2. Log In");
            System.out.println("3. Bookings");
            System.out.println("4. Chat"); // New option
            System.out.println("5. Exit");
            System.out.print("Select an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                	System.out.print("Enter your full name: ");
                    String name = scanner.nextLine();

                    System.out.print("Enter your email address: ");
                    String email = scanner.nextLine();

                    System.out.print("Enter your mobile number: ");
                    String mobile = scanner.nextLine();

                    System.out.print("Create a password: ");
                    String password = scanner.nextLine();

                    auth.signUp(name, email, mobile, password);
                    break;

                case 2:
                    System.out.print("Enter your email address: ");
                    email = scanner.nextLine();

                    System.out.print("Enter your password: ");
                    password = scanner.nextLine();

                    currentUser = auth.logIn(email, password);
                    if (currentUser != null) {
                        int transportChoice = transport.chooseTransport(currentUser); // Only pass the User object
                        double packageAmount = region.chooseRegion(currentUser, transportChoice, scanner, bookings);

                        System.out.print("Enter departure place: ");
                        String departure = scanner.nextLine();

                        System.out.print("Enter destination place: ");
                        String destination = scanner.nextLine();

                        System.out.println("Do you want to confirm the booking? (yes/no): ");
                        String confirmBooking = scanner.nextLine();

                        if (confirmBooking.equalsIgnoreCase("yes")) {
                            System.out.println("Enter date of travel: ");
                            String date = scanner.nextLine();

                            Booking booking = new Booking(currentUser.name, destination, date, packageAmount);
                            bookings.add(booking);

                            System.out.println("Booking confirmed and saved!");
                        }
                        break;
                    }
                    


                case 3:
                    if (!bookings.isEmpty()) {
                        ExcelReader.printBookings(bookings);
                    } else {
                        System.out.println("No bookings available.");
                    }
                    break;
                case 4:
                    if (currentUser != null) {
                        ChatBox chatBox = new ChatBox();
                        chatBox.startChat(currentUser);
                    } else {
                        System.out.println("Please log in first.");
                    }
                    break;


                case 5:
                    System.out.println("Exiting the application. Goodbye!");
                    ExcelWriter.writeBookingsToExcel(bookings, "bookings.xlsx");
                    System.out.println("Bookings saved to Excel.");
                    return;

                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }
}
