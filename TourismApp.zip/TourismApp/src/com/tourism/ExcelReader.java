package com.tourism;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ExcelReader {
    public static List<Booking> readBookingsFromExcel(String filePath) {
        List<Booking> bookings = new ArrayList<>();

        try (FileInputStream fileIn = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fileIn)) {
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = sheet.iterator();

            while (iterator.hasNext()) {
                Row row = iterator.next();
                String name = row.getCell(0).getStringCellValue();
                String destination = row.getCell(1).getStringCellValue();
                String date = row.getCell(2).getStringCellValue();
                double amount = row.getCell(3).getNumericCellValue();

                Booking booking = new Booking(name, destination, date, amount);
                bookings.add(booking);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return bookings;
    }

    public static void printBookings(List<Booking> bookings) {
        for (Booking booking : bookings) {
            System.out.println("Name: " + booking.getName());
            System.out.println("Destination: " + booking.getDestination());
            System.out.println("Date: " + booking.getDate());
            System.out.println("Amount: " + booking.getAmount());
            System.out.println();
        }
    }
}
