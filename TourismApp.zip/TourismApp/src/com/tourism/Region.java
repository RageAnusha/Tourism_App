package com.tourism;

import java.util.List;
import java.util.Scanner;

public class Region {
    public double chooseRegion(User currentUser, int transportChoice, Scanner scanner,List<Booking> bookings) {
        System.out.println("Select a region in India:");
        System.out.println("1. Karnataka");
        System.out.println("2. Andhra Pradesh");
        System.out.println("3. Kerala");
        System.out.println("4. Tamil Nadu");
        System.out.println("5. Telangana");
        System.out.print("Enter your choice: ");
        int regionChoice = scanner.nextInt();
        scanner.nextLine();

        double packageAmount = calculatePackageAmount(transportChoice, regionChoice);

        System.out.print("Enter departure place: ");
        String departure = scanner.nextLine();

        System.out.print("Enter destination place: ");
        String destination = scanner.nextLine();

        System.out.println("Do you want to confirm the booking? (yes/no): ");
        String confirmBooking = scanner.nextLine();

        if (confirmBooking.equalsIgnoreCase("yes")) {
            System.out.println("Enter date of travel: ");
            String date = scanner.nextLine();

            Booking booking = new Booking(currentUser.name, destination, date, packageAmount);
            bookings.add(booking);

            System.out.println("Booking confirmed and saved!");
        }
		return 0;
    }


	    double calculatePackageAmount(int transportChoice, int regionChoice) {
	        double baseAmount = 0.0;
	        double transportMultiplier = 1.0;
	        double regionMultiplier = 1.0;

	        switch (transportChoice) {
	            case 1:
	                baseAmount = 100.0;
	                break;
	            case 2:
	                baseAmount = 300.0;
	                break;
	            case 3:
	                baseAmount = 200.0;
	                break;
	            default:
	                System.out.println("Invalid transport choice.");
	                return baseAmount;
	        }

	        switch (regionChoice) {
	            case 1:
	                regionMultiplier = 1.2;
	                break;
	            case 2:
	                regionMultiplier = 1.5;
	                break;
	            case 3:
	                regionMultiplier = 1.3;
	                break;
	            case 4:
	                regionMultiplier = 1.4;
	                break;
	            default:
	                System.out.println("Invalid region choice.");
	                return regionMultiplier;
	        }

	        double packageAmount = baseAmount * transportMultiplier * regionMultiplier;
	        System.out.println("Package Amount: " + packageAmount);
			return packageAmount;
	    }
	}



