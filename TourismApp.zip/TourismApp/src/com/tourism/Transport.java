package com.tourism;
import java.util.Scanner;

public class Transport {
	String departure;
	String destination;
	
        public int chooseTransport(User currentUser) {
            if (currentUser == null) {
                System.out.println("Please log in first.");
                return 0; 
            }
        Scanner scanner = new Scanner(System.in);

        System.out.println("Select a mode of transport:");
        System.out.println("1. Road Way");
        System.out.println("2. Air way");
        System.out.println("3. Train Way");
        System.out.print("Enter your choice: ");
        int transportChoice = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Enter departure place: ");
        departure = scanner.nextLine();

        System.out.print("Enter destination place: ");
         destination = scanner.nextLine();
		return transportChoice;

       
    }
}